﻿# Equipo-Proyecto-incial-6
# Equipo-Proyecto-incial-6
SALUDOS, FUTUROS USUARIOS, HE AQUI NUESTRA QUERIDISIMA WEB... INVENTARIA!!!

En situaciones corrientes, para que la web arranque de manera inmediata solamente bastaría con hacer el comando "python manage.py runserver" pero por razones que me retengo a explicar en este README avaces falla.

En caso de falla,para que la web pueda correr ocupando tú dispositivo como servidor  recomendamos los siguientes pasos:
   
   Primer paso: ejecutar el comando "Remove-Item -Recurse -Force venv". Si por algun motivo no funciona  también puede hacer uso de fuerza bruta y hacer click derecho en la carpeta "venv" y pulsar "Delete"
   
   Segundo paso: crear un nuevo ambiente virtual con el comando "python -m venv venv"
   
   Tercer paso: activarlo (en caso de que no lo haga de manera automatica) con "venv\Scripts\activate"
   
   Cuarto paso: instalar  django con el comando "pip install django"

Y listo, haciendo todo esto no debería existir ningún problema para que la web arranque. Puede hacer "python manage.py runserver" sin ningún problema. Espero disfrute de nuestra web



Actualmente no contamos con una base de datos, pero si lo desea puede hacer lo siguiente si quiere probar nuestra funcionalidad corazon:

    Contamos con el siguiente inventario de prueba:
    INVENTARIO_PRUEBA = [
    {'id': 1, 'nombre': 'Manzanas', 'stock': 50, 'precio': 1000},
    {'id': 2, 'nombre': 'Naranjas', 'stock': 15, 'precio': 1200},
    {'id': 3, 'nombre': 'Plátanos', 'stock': 0, 'precio': 800},
]
    De aquí usted puede tomar el que desee para ver como aumentan las ganacias en nuestra pestaña de ventas, por ejemplo puede poner el dato "manzanas" y hacer que se registre una venta de 15 manzanas, podrá ver como esta no solo se registra en el historial, también puede ver la ganancia que dejó y como disminuyó la cantidad de manzanas en la pestaña stock.







Puede dejar Recomendaciones y Quejas al correo de nuestra queridisima Project Manager llamada Sofía Molina (recuerde ser siempre educado)
correo : smolinam@usm.cl















ADVERTENCIA: las soluciones que damos son para que se activen desde porwshell en VScode, desconozco lo necesario si se ocupa otro editor de codigo fuente (recomendamos ocupar VScode [Vscode no nos esta pagando])
Recuerde que los comandos se tienen que ocupar sin las comillas ""
